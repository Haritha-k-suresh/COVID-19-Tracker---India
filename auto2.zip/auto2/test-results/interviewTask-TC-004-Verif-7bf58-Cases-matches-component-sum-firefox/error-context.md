# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: interviewTask.spec.js >> TC_004 Verify Total Cases matches component sum
- Location: tests\interviewTask.spec.js:39:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 212704
Received: 212705
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - heading "COVID-19 Tracker - India" [level=1] [ref=e5]
    - combobox [ref=e6]:
      - option "Select a State"
      - option "Andhra Pradesh"
      - option "Arunachal Pradesh"
      - option "Assam"
      - option "Bihar" [selected]
      - option "Chhattisgarh"
      - option "Goa"
      - option "Gujarat"
      - option "Haryana"
      - option "Himachal Pradesh"
      - option "Jharkhand"
      - option "Karnataka"
      - option "Kerala"
      - option "Madhya Pradesh"
      - option "Maharashtra"
      - option "Manipur"
      - option "Meghalaya"
      - option "Mizoram"
      - option "Nagaland"
      - option "Odisha"
      - option "Punjab"
      - option "Rajasthan"
      - option "Sikkim"
      - option "Tamil Nadu"
      - option "Telangana"
      - option "Tripura"
      - option "Uttar Pradesh"
      - option "Uttarakhand"
      - option "West Bengal"
    - generic [ref=e7]:
      - heading "Results for Bihar" [level=2] [ref=e8]
      - generic [ref=e9]:
        - paragraph [ref=e10]:
          - strong [ref=e11]: "Total Cases :"
          - text: "212705"
        - paragraph [ref=e12]:
          - strong [ref=e13]: "Active Cases :"
          - text: "9639"
        - paragraph [ref=e14]:
          - strong [ref=e15]: "Recovered :"
          - text: "202007"
        - paragraph [ref=e16]:
          - strong [ref=e17]: "Deaths :"
          - text: "1058"
  - generic [ref=e21]:
    - img:
      - generic:
        - generic:
          - generic: 50%
          - generic: 47.5%
          - generic: 2.27%
          - generic: 0.249%
    - img:
      - generic:
        - generic [ref=e29]:
          - generic [ref=e30]:
            - text: Total
            - generic [ref=e35] [cursor=pointer]
          - generic [ref=e36]:
            - text: Recovered
            - generic [ref=e41] [cursor=pointer]
          - generic [ref=e42]:
            - text: Active Cases
            - generic [ref=e47] [cursor=pointer]
          - generic [ref=e48]:
            - text: Deaths
            - generic [ref=e53] [cursor=pointer]
        - generic: COVID-19 Distribution(Pie Chart)
    - generic [ref=e54]:
      - generic [ref=e56] [cursor=pointer]
      - link "plotly-logomark" [ref=e60] [cursor=pointer]:
        - /url: https://plotly.com/
        - img "plotly-logomark" [ref=e61]
  - generic [ref=e77]:
    - img:
      - generic:
        - generic:
          - generic:
            - generic: Total Cases
            - generic: Recovered
            - generic: Deaths
            - generic: Active Cases
          - generic:
            - generic: "0"
            - generic: 50k
            - generic: 100k
            - generic: 150k
            - generic: 200k
    - img:
      - generic:
        - generic [ref=e94]:
          - generic [ref=e95]:
            - text: Total Cases
            - generic [ref=e102] [cursor=pointer]
          - generic [ref=e103]:
            - text: Recovered
            - generic [ref=e110] [cursor=pointer]
          - generic [ref=e111]:
            - text: Deaths
            - generic [ref=e118] [cursor=pointer]
          - generic [ref=e119]:
            - text: Active Cases
            - generic [ref=e126] [cursor=pointer]
        - generic: "COVID-19 Cases : Line Chart Representation"
        - generic: Case Category
        - generic: Number of Cases
    - generic [ref=e127]:
      - generic [ref=e129] [cursor=pointer]
      - generic [ref=e132]:
        - generic [ref=e133] [cursor=pointer]
        - generic [ref=e136] [cursor=pointer]
        - generic [ref=e139] [cursor=pointer]
        - generic [ref=e142] [cursor=pointer]
      - generic [ref=e145]:
        - generic [ref=e146] [cursor=pointer]
        - generic [ref=e149] [cursor=pointer]
        - generic [ref=e152] [cursor=pointer]
        - generic [ref=e155] [cursor=pointer]
      - link "plotly-logomark" [ref=e159] [cursor=pointer]:
        - /url: https://plotly.com/
        - img "plotly-logomark" [ref=e160]
  - generic [ref=e174]:
    - button "Marker" [ref=e175] [cursor=pointer]
    - generic:
      - generic [ref=e176]:
        - button "Zoom in" [ref=e177] [cursor=pointer]: +
        - button "Zoom out" [ref=e178] [cursor=pointer]: −
      - generic [ref=e179]:
        - link "Leaflet" [ref=e180] [cursor=pointer]:
          - /url: https://leafletjs.com
        - text: "| ©"
        - link "OpenStreetMap" [ref=e185] [cursor=pointer]:
          - /url: https://www.openstreetmap.org/copyright
        - text: contributors
```

# Test source

```ts
  1  | const { test, expect } = require('@playwright/test');
  2  | const HomePage = require('../pages/HomePage');
  3  | const { baseUrl } = require('../config/env');
  4  | const { extractNumber } = require('../utils/helpers');
  5  | 
  6  | const selectedState = 'Bihar';
  7  | 
  8  | async function openBihar(page) {
  9  |   const home = new HomePage(page);
  10 |   await home.open(baseUrl);
  11 |   await home.selectState(selectedState);
  12 |   await home.resultHeading.waitFor();
  13 |   return home;
  14 | }
  15 | 
  16 | test('TC_001 Verify COVID-19 Tracker heading', async ({ page }) => {
  17 |   await page.goto(baseUrl);
  18 | 
  19 |   await expect(page.getByRole('heading', { name: 'COVID-19 Tracker - India' })).toBeVisible();
  20 | });
  21 | 
  22 | test('TC_002 Verify State dropdown options are displayed', async ({ page }) => {
  23 |   const home = new HomePage(page);
  24 |   await home.open(baseUrl);
  25 | 
  26 |   await expect(home.stateDropdown).toBeVisible();
  27 |   const states = await home.getStateNames();
  28 | 
  29 |   console.log('Total States:', states.length);
  30 |   expect(states.length).toBeGreaterThan(1);
  31 | });
  32 | 
  33 | test('TC_003 Verify pie chart is visible after selecting Bihar', async ({ page }) => {
  34 |   const home = await openBihar(page);
  35 | 
  36 |   await expect(home.pieChart).toBeVisible();
  37 | });
  38 | 
  39 | test('TC_004 Verify Total Cases matches component sum', async ({ page }) => {
  40 |   const home = await openBihar(page);
  41 | 
  42 |   const totalCases = extractNumber(await home.totalCases.textContent());
  43 |   const activeCases = extractNumber(await home.activeCases.textContent());
  44 |   const recovered = extractNumber(await home.recovered.textContent());
  45 |   const deaths = extractNumber(await home.deaths.textContent());
  46 | 
> 47 |   expect(totalCases).toBe(activeCases + recovered + deaths);
     |                      ^ Error: expect(received).toBe(expected) // Object.is equality
  48 | });
  49 | 
  50 | test('TC_005 Verify result cards are displayed properly', async ({ page }) => {
  51 |   const home = await openBihar(page);
  52 | 
  53 |   await expect(home.totalCases).toBeVisible();
  54 |   await expect(home.activeCases).toBeVisible();
  55 |   await expect(home.recovered).toBeVisible();
  56 |   await expect(home.deaths).toBeVisible();
  57 | });
```